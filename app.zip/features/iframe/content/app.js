(function () { 'use strict';

  angular.module('ClearCodeApp', ['options']);

})();
