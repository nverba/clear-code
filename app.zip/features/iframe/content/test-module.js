(function () { 'use strict';

  // This module is injected for simplicity, the testing service (injected dynamically) exposes a testrunner api to the console.

  angular.module('TestModule', ['options']);

})();
