var ClearCodeApp = angular.module('ClearCodeApp', ['optionsService']);
